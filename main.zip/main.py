import pygame
import sys
import random

from map_generator import new_island
from images import item_images
from game_entities import Player
from camera import Camera
import stamina
import inventory

from sprite import load_sprite_sheets, AnimationManager


class Game:

    @staticmethod
    def handle_events():
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

    def __init__(self):
        self.screen_x = 1000
        self.screen_y = 750
        pygame.init()
        self.screen = pygame.display.set_mode((self.screen_x, self.screen_y))
        pygame.display.set_caption("GA")
        self.set_frame_rate = pygame.time.Clock()
        self.stamina_bar_decay = 0

        self.player = Player(
            max_health=20, min_health=0,
            max_stamina=20, min_stamina=0,
            base_speed=4, max_speed=10, min_speed=1
        )

        # Game-related attributes
        self.block_size = 100
        self.player_size = self.block_size / 2
        self.player_color = 'red'
        self.base_speed = 20
        self.generated_ground_images = None
        self.grab_decay = 0

        # Inventory display settings
        self.inventory_display_rects = [
            pygame.Rect(50, 50, 50, 50),
            pygame.Rect(100, 50, 50, 50),
            pygame.Rect(150, 50, 50, 50),
            pygame.Rect(200, 50, 50, 50),
            pygame.Rect(250, 50, 50, 50),
            pygame.Rect(300, 50, 50, 50),
            pygame.Rect(350, 50, 50, 50),
            pygame.Rect(400, 50, 50, 50),
            pygame.Rect(450, 50, 50, 50),
        ]

        self.inventory = {}  # Terve inv (prindi seda ja saad teada mis invis on)

        self.offset_x = 0
        self.offset_y = 0
        self.X_max = 1500 // self.block_size
        self.Y_max = 1500 // self.block_size
        self.center_x = self.X_max // 2
        self.center_y = self.Y_max // 2
        self.max_distance = min(self.center_x, self.center_y)

        self.terrain_data = [[0 for _ in range(self.Y_max)] for _ in range(self.X_max)]

        new_island(self, 64)

        self.player_x = random.randint(400, 600)
        self.player_y = random.randint(200, 550)
        self.player_rect = pygame.Rect(self.player_x, self.player_y, self.player_size, self.player_size)

        print(self.player_rect.left, self.player_rect.right,
              self.player_rect.top, self.player_rect.bottom)

        # interaction box
        self.interaction_rect = pygame.Rect(0, 0, 0, 0)

        # stamina
        self.stamina_bar_decay = 0

        # stamina bar
        self.stamina_bar_size = 200
        self.stamina_bar_size_bg = 200
        self.stamina_bar_size_border = 200

        self.screen_x = 1000
        self.screen_y = 750
        self.screen = pygame.display.set_mode((self.screen_x, self.screen_y))
        self.half_w = self.screen.get_size()[0] // 2


        self.ratio = self.stamina_bar_size // 20  # 200 // 20 = 10

        self.stamina_rect_bg = pygame.Rect(self.half_w - (self.stamina_bar_size_bg / 2) - 6, self.screen_y - 25, self.stamina_bar_size_bg + 12, 15)  # Kui staminat kulub, ss on background taga
        self.stamina_rect_border = pygame.Rect(self.half_w - (self.stamina_bar_size_border / 2) - 6, self.screen_y - 25, self.stamina_bar_size_border + 12, 15)  # K6igi stamina baride ymber border
        self.stamina_rect = pygame.Rect(self.half_w - (self.stamina_bar_size / 2) - 6, self.screen_y - 25, self.stamina_bar_size + 12, 15)


        # Animation shit
        self.sprite_sheets, self.animations = load_sprite_sheets([
            'images/Player/Left.png',
            'images/Player/Right.png',
            'images/Player/Up.png',
            'images/Player/Down.png'
        ])

        self.sprite_sheets_idle, self.animations_idle = load_sprite_sheets([
            'images/Player/Idle_Left.png',
            'images/Player/Idle_Right.png',
            'images/Player/Idle_Up.png',
            'images/Player/Idle_Down.png'
        ])

        # Set animation speeds
        self.animation_speeds = [10, 10, 10, 10]  # Example speeds, adjust as needed

        # Create AnimationManagers for both regular and idle animations
        self.animation_manager = AnimationManager(self.sprite_sheets, self.animations, self.animation_speeds)
        self.idle_animation_manager = AnimationManager(self.sprite_sheets_idle, self.animations_idle,
                                                       self.animation_speeds)

        keys = pygame.key.get_pressed()
        is_idle = not (keys[pygame.K_a] or keys[pygame.K_d] or keys[pygame.K_w] or keys[pygame.K_s] or keys[
            pygame.K_e])

        # Use the appropriate AnimationManager based on idle status
        if is_idle:
            self.frame = self.idle_animation_manager.update_animation(keys, is_idle)
        else:
            self.frame = self.animation_manager.update_animation(keys, is_idle)

        if self.frame is not None:
            self.sprite_rect = self.screen.blit(self.frame, (self.player_x, self.player_y))
            # print(self.sprite_rect.left, self.sprite_rect.right,
            #       self.sprite_rect.top, self.sprite_rect.bottom)

    # Uuendab player datat ja laseb tal liikuda
    def update_player(self):
        # Jälgib keyboard inputte
        keys = pygame.key.get_pressed()

        # Teeb uue player x/y, algne x ja y tuleb playeri maailma panekuga (randint)
        new_player_x = self.player_x
        new_player_y = self.player_y

        # Playeri itemite korjamise kast
        interaction_x = self.player_rect.left + self.offset_x
        interaction_y = self.player_rect.top + self.offset_y

        # Kui player korjab midagi ülesse (Animationi jaoks - GRABBING)
        # 20 fps cooldown
        if keys[pygame.K_e]:
            if self.grab_decay >= 20:
                inventory.item_interaction(self) # Loeb ja korjab itemeid

            else:
                self.grab_decay += 1

        if keys[pygame.K_a]:
            new_player_x = self.player_x - self.player.speed
            self.interaction_rect = pygame.Rect(interaction_x - self.block_size * 2, interaction_y - self.block_size / 1.35, 2 * self.block_size, 2 * self.block_size)
            # Animation VASAKULE + animationi kiirus (in fps)

        if keys[pygame.K_d]:
            new_player_x = self.player_x + self.player.speed
            self.interaction_rect = pygame.Rect(interaction_x + self.block_size / 2, interaction_y - self.block_size / 1.35, 2 * self.block_size, 2 * self.block_size)
            # Animation PAREMALE + animationi kiirus (in fps)

        if keys[pygame.K_w]:
            new_player_y = self.player_y - self.player.speed
            self.interaction_rect = pygame.Rect(interaction_x - self.block_size / 1.35, interaction_y - self.block_size * 2, 2 * self.block_size, 2 * self.block_size)
            # Animation ÜLESSE + animationi kiirus (in fps)

        if keys[pygame.K_s]:
            new_player_y = self.player_y + self.player.speed
            self.interaction_rect = pygame.Rect(interaction_x - self.block_size / 1.35, interaction_y + self.block_size / 2, 2 * self.block_size, 2 * self.block_size)
            # Animation ALLA + animationi kiirus (in fps)

        # Kui hoitakse all Shifti ja a, d, w, s:
        # Muudetakse playeri speedi ja võetakse staminat.
        if keys[pygame.K_LSHIFT]:
            if keys[pygame.K_a] or keys[pygame.K_d] or keys[pygame.K_w] or keys[pygame.K_s]:
                self.stamina_bar_decay = 0  # Kui stamina bari pole siis tuleb kui player liigub
                self.player.speed = self.base_speed * 5
                self.player.stamina.use_stamina(0.05)

                # Kiirendab animationi - näeb välja nagu jookseks
                # animationi kiirus * 2 (in fps)

            # stamina = 0 --- playeri speed = base speed
            if self.player.stamina.current_stamina == 0:
                self.player.speed = self.base_speed
                self.player.stamina.stamina_regenerate(0.05)

        # Kui ei hoia shifti all siis regeneb staminat
        if not keys[pygame.K_LSHIFT]:
            self.player.stamina.stamina_regenerate(0.05)
            self.player.speed = self.base_speed

        # Kui seda pole siis player ei liigu mapi peal
        # Uuendab playeri asukohta vastavalt keyboard inputile
        self.player_x = new_player_x
        self.player_y = new_player_y
        self.player_rect = pygame.Rect(self.player_x, self.player_y, self.player_size, self.player_size)


        # Kui player seisab (Animationi jaoks - IDLE)
        # Determine if the player is idle or not
        is_idle = not (keys[pygame.K_a] or keys[pygame.K_d] or keys[pygame.K_w] or keys[pygame.K_s] or keys[
            pygame.K_e])

        # Use the appropriate AnimationManager based on idle status
        if is_idle:
            self.frame = self.idle_animation_manager.update_animation(keys, is_idle)
        else:
            self.frame = self.animation_manager.update_animation(keys, is_idle)

        if self.frame is not None:
            self.sprite_rect = self.screen.blit(self.frame, (self.player_x, self.player_y))
            # print(self.sprite_rect.left, self.sprite_rect.right,
            #       self.sprite_rect.top, self.sprite_rect.bottom)


    def check_collisions(self):
        keys = pygame.key.get_pressed()
        for i in range(len(self.terrain_data)):
            for j in range(len(self.terrain_data[i])):
                terrain_rect = pygame.Rect(
                    j * self.block_size,
                    i * self.block_size,
                    self.block_size,
                    self.block_size
                )

                if self.player_rect.colliderect(terrain_rect):
                    in_water = any(
                        self.terrain_data[row][col] == 0
                        for row in range(i, i - 1, -1)
                        for col in range(j, j - 1, -1)
                    )

                    if in_water:
                        if keys[pygame.K_LSHIFT]:
                            self.player.speed = self.base_speed

                        else:
                            self.player.speed = self.base_speed / 10

    def render(self):
        # Tühjendab ekraani siniseks
        self.screen.fill('blue')

        # Joonistab maastiku
        for i in range(len(self.terrain_data)):
            for j in range(len(self.terrain_data[i])):
                terrain_x = j * self.block_size + self.offset_x
                terrain_y = i * self.block_size + self.offset_y

                # Joonistab maapinna
                ground_image = self.generated_ground_images.get((i, j))
                if ground_image:
                    ground_image = pygame.transform.scale(ground_image, (self.block_size, self.block_size))
                    self.screen.blit(ground_image, (terrain_x, terrain_y))

                # Joonistab objekte, kui andmetel pole väärtus 0 (vesi)
                if self.terrain_data[i][j] != 0:
                    item_image = None
                    if self.terrain_data[i][j] == 2:
                        item_image = item_images.get("Rock")
                    elif self.terrain_data[i][j] == 4:
                        item_image = item_images.get("Tree")
                        if item_image:
                            # Suurendab puu suurust
                            item_image = pygame.transform.scale(item_image, (self.block_size * 2, self.block_size * 2))
                            self.screen.blit(item_image, (terrain_x - self.block_size, terrain_y - self.block_size))
                            continue  # Jätkab järgmise ploki renderdamist, kui puu on suurendatud

                    if item_image is not None:
                        item_image = pygame.transform.scale(item_image, (self.block_size, self.block_size))
                        self.screen.blit(item_image, (terrain_x, terrain_y))

        # Korrigeerib mängija suurust ja asukohta vastavalt kaamerale
        player_rect_adjusted = pygame.Rect(
            self.player_rect.left + self.offset_x,
            self.player_rect.top + self.offset_y,
            self.player_size,
            self.player_size,
        )

        # Korrigeerib mängija suurust ja asukohta vastavalt kaamerale
        sprite_rect_adjusted = pygame.Rect(
            self.sprite_rect.left + self.offset_x,
            self.sprite_rect.top + self.offset_y,
            self.player_size,
            self.player_size,
        )

        # Joonistab stamina ribad ja mängija asukoha markeri
        if self.stamina_bar_decay < 50:
            pygame.draw.rect(self.screen, '#F7F7F6', self.stamina_rect_bg, 0, 7)
            pygame.draw.rect(self.screen, '#4169E1', self.stamina_rect, 0, 7)
            pygame.draw.rect(self.screen, 'black', self.stamina_rect_border, 2, 7)

        pygame.draw.rect(self.screen, 'yellow', self.camera_rect, 2)
        pygame.draw.rect(self.screen, 'yellow', self.interaction_rect, 2)
        pygame.draw.rect(self.screen, self.player_color, player_rect_adjusted)
        self.screen.blit(self.frame, (sprite_rect_adjusted[0], sprite_rect_adjusted[1]))

        # Renderdab inventuuri
        inventory.render_inventory(self)

        # Värskendab ekraani ja hoiab mängu kiirust 60 kaadrit sekundis
        pygame.display.flip()
        self.set_frame_rate.tick(60)


    def run(self):
        while True:
            self.handle_events()  # Paneb mängu õigesti kinni
            self.update_player()  # Uuendab mängija asukohta, ja muid asju
            Camera.box_target_camera(self)  # Box camera, et player ei saaks boxist välja minna vms
            self.check_collisions()  # Vaatab mängija ja maastiku kokkupõrkeidW
            stamina.stamina_bar_update(self)  # Stamina bar
            self.render()  # Renderib terraini

if __name__ == "__main__":
    game = Game()
    game.run()